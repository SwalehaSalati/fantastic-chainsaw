package com.practice.model;

import java.io.Serializable;
import java.util.Date;

public class Rental implements Serializable {
	
	private static final long serialVersionUID = -4494589428451007317L;
	private int rentalId;
	private Customer customer;
	private Car car;
	private Date hireDate;
	private Date returnDate;
	private double totalKms;
	/**
	 * @return the rentalId
	 */
	public int getRentalId() {
		return rentalId;
	}
	/**
	 * @param rentalId the rentalId to set
	 */
	public void setRentalId(int rentalId) {
		this.rentalId = rentalId;
	}
	/**
	 * @return the customer
	 */
	public Customer getCustomer() {
		return customer;
	}
	/**
	 * @param customer the customer to set
	 */
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	/**
	 * @return the car
	 */
	public Car getCar() {
		return car;
	}
	/**
	 * @param car the car to set
	 */
	public void setCar(Car car) {
		this.car = car;
	}
	/**
	 * @return the hireDate
	 */
	public Date getHireDate() {
		return hireDate;
	}
	/**
	 * @param hireDate the hireDate to set
	 */
	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}
	/**
	 * @return the returnDate
	 */
	public Date getReturnDate() {
		return returnDate;
	}
	/**
	 * @param returnDate the returnDate to set
	 */
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}
	/**
	 * @return the totalKms
	 */
	public double getTotalKms() {
		return totalKms;
	}
	/**
	 * @param totalKms the totalKms to set
	 */
	public void setTotalKms(double totalKms) {
		this.totalKms = totalKms;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((car == null) ? 0 : car.hashCode());
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + rentalId;
		long temp;
		temp = Double.doubleToLongBits(totalKms);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Rental other = (Rental) obj;
		if (car == null) {
			if (other.car != null)
				return false;
		} else if (!car.equals(other.car))
			return false;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (rentalId != other.rentalId)
			return false;
		if (Double.doubleToLongBits(totalKms) != Double.doubleToLongBits(other.totalKms))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Rental [rentalId=" + rentalId + ", customer=" + customer + ", car=" + car + ", totalKms=" + totalKms
				+ "]";
	}
	
	

}
