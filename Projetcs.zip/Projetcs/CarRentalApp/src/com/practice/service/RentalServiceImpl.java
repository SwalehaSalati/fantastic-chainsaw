/**
 * 
 */
package com.practice.service;

import java.util.List;

import com.practice.dao.CarDao;
import com.practice.dao.DaoFactory;
import com.practice.dao.RentalDao;
import com.practice.exception.ApplicationException;
import com.practice.exception.DaoException;
import com.practice.exception.ServiceException;
import com.practice.model.Car;
import com.practice.model.Category;
import com.practice.model.Customer;
import com.practice.model.Rental;

/**
 * @author Swaleha
 *
 */
public class RentalServiceImpl implements RentalService {

	/* (non-Javadoc)
	 * @see com..service.RentalService#addCar(com.practice.model.Car)
	 */
	@Override
	public void addCar(Car car) throws ServiceException {
		try {
			CarDao carDao = DaoFactory.getInstance().getCarDao();
			carDao.addCar(car);
		} catch (DaoException e) {
	 		 throw new ServiceException("Rental Service not Available", e);
		}
		catch (ApplicationException e) {
			throw new ServiceException("Rental Service not Available", e);
		}
	}

	/* (non-Javadoc)
	 * @see com.practice.service.RentalService#getAllCategories()
	 */
	@Override
	public List<Category> getAllCategories() throws ServiceException {
		try {
			CarDao carDao = DaoFactory.getInstance().getCarDao();
			return carDao.getCategories();
		} catch (DaoException e) {
	 		 throw new ServiceException("Rental Service not Available", e);
		}
		catch (ApplicationException e) {
			throw new ServiceException("Rental Service not Available", e);
		}
	}

	/* (non-Javadoc)
	 * @see com.practice.service.RentalService#getRental(com.practice.model.Car)
	 */
	@Override
	public List<Rental> getRental(Car car) throws ServiceException {
		// TODO Auto-generated method stub
		try {
			RentalDao rentalDao = DaoFactory.getInstance().getRentalDao();
			return rentalDao.getRentals(car);
		} catch (DaoException e) {
	 		 throw new ServiceException("Rental Service not Available", e);
		}
		catch (ApplicationException e) {
			throw new ServiceException("Rental Service not Available", e);
		}	
		
	}

	/* (non-Javadoc)
	 * @see com.practice.service.RentalService#rentCar(com.practice.model.Rental)
	 */
	@Override
	public void rentCar(Rental rental) throws ServiceException {
		// TODO Auto-generated method stub
		try {
			RentalDao rentalDao = DaoFactory.getInstance().getRentalDao();
			rentalDao.rentCar(rental);
		} catch (DaoException e) {
	 		 throw new ServiceException("Rental Service not Available", e);
		}
		catch (ApplicationException e) {
			throw new ServiceException("Rental Service not Available", e);
		}
	}

	@Override
	public List<Car> getCars() throws ServiceException {
		try {
			RentalDao rentalDao = DaoFactory.getInstance().getRentalDao();
			return rentalDao.getAllCars();
		} catch (DaoException e) {
	 		 throw new ServiceException("Rental Service not Available", e);
		}
		catch (ApplicationException e) {
			throw new ServiceException("Rental Service not Available", e);
		}
	}

	@Override
	public List<Customer> getCustomers() throws ServiceException {
		try {
			RentalDao rentalDao = DaoFactory.getInstance().getRentalDao();
			return rentalDao.getAllCustomers();
		} catch (DaoException e) {
	 		 throw new ServiceException("Rental Service not Available", e);
		}
		catch (ApplicationException e) {
			throw new ServiceException("Rental Service not Available", e);
		}
	}

}
