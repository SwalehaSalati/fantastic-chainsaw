package com.practice.service;

import java.util.List;

import com.practice.exception.ServiceException;
import com.practice.model.Car;
import com.practice.model.Category;
import com.practice.model.Customer;
import com.practice.model.Rental;

public interface RentalService {
	public List<Category> getAllCategories() throws ServiceException;
	public void addCar(Car car) throws ServiceException;
	public void rentCar(Rental rental) throws ServiceException;
	public List<Rental> getRental(Car car) throws ServiceException;
	
	public List<Customer> getCustomers() throws ServiceException;
	public List<Car> getCars() throws ServiceException;
}
