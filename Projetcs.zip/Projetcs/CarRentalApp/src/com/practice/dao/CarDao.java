package com.practice.dao;

import java.util.List;

import com.practice.exception.DaoException;
import com.practice.model.Car;
import com.practice.model.Category;

public interface CarDao {
	
	public void addCar(Car car) throws DaoException;
	public List<Category> getCategories() throws DaoException;
}
