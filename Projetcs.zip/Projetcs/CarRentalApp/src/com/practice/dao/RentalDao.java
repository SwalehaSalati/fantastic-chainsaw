package com.practice.dao;

import java.util.List;

import com.practice.exception.DaoException;
import com.practice.model.Car;
import com.practice.model.Customer;
import com.practice.model.Rental;

public interface RentalDao {
	
	public void rentCar(Rental rental) throws DaoException;
	
	public List<Rental> getRentals(Car car) throws DaoException;
	
	public List<Customer> getAllCustomers() throws DaoException;
	
	public List<Car> getAllCars() throws DaoException;
}
