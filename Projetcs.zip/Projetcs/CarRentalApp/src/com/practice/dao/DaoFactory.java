package com.practice.dao;

import com.practice.exception.*;

import java.util.ResourceBundle;



public class DaoFactory {
	private static DaoFactory instance = null;
	private String carDao;
	private String rentalDao;
	 
	private DaoFactory() {
		ResourceBundle resource = ResourceBundle
				.getBundle("com.practice.dao.DBConfig");
		carDao = resource.getString("carDao");
		rentalDao = resource.getString("rentalDao");
	}

	//@SuppressWarnings("deprecation")
	public CarDao getCarDao() throws ApplicationException {
		try {
			return (CarDao) Class.forName(carDao).getDeclaredConstructor().newInstance();
		} catch (Exception e) {
			throw new ApplicationException("Unable to Get CarDao", e);
		}
	}
	public RentalDao getRentalDao() throws ApplicationException {
		try {
			return (RentalDao) Class.forName(rentalDao).getDeclaredConstructor().newInstance();
		} catch (Exception e) {
			throw new ApplicationException("Unable to Get rentalDao", e);
		}
	}
	
	public  static DaoFactory getInstance() {
		if (instance == null) {
			synchronized (DaoFactory.class) {
				instance = new DaoFactory();
			}
		}
		return instance;
	}
}
