package com.practice.dao.jdbcImpl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.practice.dao.RentalDao;
import com.practice.exception.DaoException;
import com.practice.model.Car;
import com.practice.model.Customer;
import com.practice.model.Rental;



public class RentalDaoJdbcImpl extends BaseDao implements RentalDao {

	private static final String GET_ALL_CUSTOMERS =
			"select ID,USERNAME,PASSWORD from customer";
	private static final String GET_ALL_CARS =
			"select Car_ID,REG_NO from car";
	private static final String INSERT_RENATL =
			"insert into Rental(RENTAL_ID,ID,CAR_ID,HIRE_DATE,RETURN_DATE,TOTAL_KM) values (?,?,?,?,?,?)";
	
	private static final String GET_RENTAL =
			"Select RENTAL_ID,ID,CAR_ID,HIRE_DATE,RETURN_DATE,TOTAL_KM from rental where CAR_ID=?";
	
	public List<Car> getAllCars() throws DaoException {
		 Connection con = null;
		 con = getConnection();
		 PreparedStatement psmt  = null;
		 List<Car> carList = new ArrayList<Car>();
		 try {
			psmt = con.prepareStatement(GET_ALL_CARS);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				Car car = new Car();
					car.setCarId(rs.getInt("CAR_ID"));
					car.setRegistrationNo(rs.getString("REG_NO"));
				carList.add(car);
			}
		} catch (SQLException e) {
			throw new DaoException("Not able to get car List", e);
		} finally {
			closeResource(psmt, con);
		}
	 	return carList;
	}

	@Override
	public List<Customer> getAllCustomers() throws DaoException {
		Connection con = null;
		 con = getConnection();
		 PreparedStatement psmt  = null;
		 List<Customer> customerList = new ArrayList<Customer>();
		 try {
			psmt = con.prepareStatement(GET_ALL_CUSTOMERS);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				Customer customer = new Customer();
				customer.setId(rs.getInt("ID"));
				customer.setUserName(rs.getString("USERNAME"));
				customerList.add(customer);
			}
		} catch (SQLException e) {
			throw new DaoException("Not able to get customer  List", e);
		} finally {
			closeResource(psmt, con);
		}
	 	return customerList;
	}

	@Override
	public List<Rental> getRentals(Car car) throws DaoException {
		// TODO Auto-generated method stub
		 Connection con = null;
		 con = getConnection();
		 PreparedStatement psmt  = null;
		 List<Rental> rentals = new ArrayList<Rental>();
		 try {
			psmt = con.prepareStatement(GET_RENTAL);
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				Rental rental = new Rental();
					rental.setCar((Car) rs.getObject("CAR_ID"));
					rental.setCustomer((Customer)(rs.getObject("ID")));
				rentals.add(rental);
			}
		} catch (SQLException e) {
			throw new DaoException("Not able to get car List", e);
		} finally {
			closeResource(psmt, con);
		}
	 	return rentals;
	}
	
	private int getNextRentalId(Connection con) throws SQLException {
		String sql = "select Max(RENTAL_ID) from rental";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql) ;
		if(rs.next()) {
			return rs.getInt(1) + 1;
		}
		return 1;
	}

	@Override
	public void rentCar(Rental rental) throws DaoException {
		// TODO Auto-generated method stub
		Connection con = null;
		 con = getConnection();
		 PreparedStatement psmt  = null;
		 try {
			psmt = con.prepareStatement(INSERT_RENATL);
			psmt.setInt(1, getNextRentalId(con));
			psmt.setInt(3, rental.getCustomer().getId());
			psmt.setInt(2, rental.getCar().getCarId());
			psmt.setDate(4, new java.sql.Date(rental.getHireDate().getTime()));
			psmt.setDate(5,new java.sql.Date(rental.getReturnDate().getTime()));
			psmt.setDouble(6, rental.getTotalKms());
			
			if(psmt.executeUpdate() != 1) {
				throw new DaoException("Not able to Add Rental");
			}
		} catch (SQLException e) {
			throw new DaoException("Not able to Add Rental", e);
		} finally {
			closeResource(psmt, con);
		}

	}

}
